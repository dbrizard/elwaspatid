# Wave space-time diagrams

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

## Installation

`pip install wave-space-time-diagrams`

## Usage

`add_ones(5)`

## Credit

LBMC

from .elwaspatid import Waveprop, WP2, BarSingle, BarSet, ElasticImpact
# from .elwaspatid import Bar, Segment  # These class are not called directly by the used
from .elwaspatid import trapezeWave, groovedBar

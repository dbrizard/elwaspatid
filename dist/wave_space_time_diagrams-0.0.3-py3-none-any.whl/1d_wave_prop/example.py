"""
This is a test module. with one function.


"""

def add_one(number):
    """Add one to the input number"""
    return number + 1
